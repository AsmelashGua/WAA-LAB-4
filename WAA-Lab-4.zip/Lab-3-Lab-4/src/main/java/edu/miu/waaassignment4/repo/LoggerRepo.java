package edu.miu.waaassignment4.repo;

import edu.miu.waaassignment4.entity.Logger;
import org.springframework.data.repository.CrudRepository;

public interface LoggerRepo extends CrudRepository<Logger, Long> {
}
