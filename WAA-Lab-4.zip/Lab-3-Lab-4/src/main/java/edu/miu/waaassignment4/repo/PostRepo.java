package edu.miu.waaassignment4.repo;

import edu.miu.waaassignment4.entity.Post;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepo extends CrudRepository<Post, Long> {

    //@Query("SELECT P FROM Post p WHERE p.title = :param");
    public List<Post> findAllByTitleEquals(String param);


}
