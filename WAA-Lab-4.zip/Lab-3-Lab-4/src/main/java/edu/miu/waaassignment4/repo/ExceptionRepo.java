package edu.miu.waaassignment4.repo;

import edu.miu.waaassignment4.entity.Exception;
import org.springframework.data.repository.CrudRepository;

public interface ExceptionRepo extends CrudRepository<Exception, Long> {
}
